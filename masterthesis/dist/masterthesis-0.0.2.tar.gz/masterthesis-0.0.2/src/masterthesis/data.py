import os
from scanpy import read_h5ad

data_dir = os.path.join(os.path.dirname(__file__), "data")

def load_acinar():
    acinar = read_h5ad(os.path.join(data_dir, "acinar_sce.h5ad"))
    return acinar


def load_hesc():
    hesc = read_h5ad(os.path.join(data_dir, "hesc_sce.h5ad"))
    return hesc


def load_beta():
    beta = read_h5ad(os.path.join(data_dir, 'beta_sce.h5ad'))
    return beta


def load_germ():
    germ = read_h5ad(os.path.join(data_dir, 'germ_sce.h5ad'))
    return germ


def load_colon():
    colon = read_h5ad(os.path.join(data_dir, 'colon_sce.h5ad'))
    return colon


def load_mef():
    mef = read_h5ad(os.path.join(data_dir, 'mef_sce.h5ad'))
    return mef
